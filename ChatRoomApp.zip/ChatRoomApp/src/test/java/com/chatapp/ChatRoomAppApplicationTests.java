package com.chatapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatRoomAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
